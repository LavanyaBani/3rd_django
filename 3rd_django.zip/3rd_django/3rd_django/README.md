# 3rd_django
3rdst django homework project
